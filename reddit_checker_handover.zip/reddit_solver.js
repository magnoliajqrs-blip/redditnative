/**
 * Reddit Login Solver with reCAPTCHA Enterprise v3
 *
 * Complete flow:
 *   1. Reddit JS challenge (GET /login → solve → GET /login?solution=...)
 *   2. reCAPTCHA anchor (GET anchor page → extract token + init params)
 *   3. reCAPTCHA reload (POST protobuf → get final token)
 *   4. Reddit login API (POST with reCAPTCHA token)
 *
 * FREE STEALTH ARCHITECTURE:
 * - Puppeteer Extra Stealth (JavaScript-Based)
 * - Bypass Detect-Browser Test
 * - Random Device/Driver Mapping
 * - Popup/Mouse Events (Free, no payment)
 * - Rate Limiting with Entropy
 * - TLS Spoofing + Chrome131
 *
 * ZERO PAYMENTS REQUIRED:
 * - BotGuard handles reCAPTCHA solving (FREE)
 * - No 2captcha/digital-ascape dependencies
 * - Pure Puppeteer + StealthPlugin
 */

// ============================================================
// FREE STEALTH ENHANCEMENTS
// ============================================================

const { Session, initTLS } = require('node-tls-client');
const https = require('https');
const http = require('http');
const { URL, URLSearchParams } = require('url');
const crypto = require('crypto');
const { Buffer } = require('buffer');
const zlib = require('zlib');
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');

// Add additional stealth plugins for free anti-detection
puppeteer.use(StealthPlugin());

// Add additional stealth plugins for free anti-detection
const howlerPlugin = require('puppeteer-extra-plugin-stealth');
puppeteer.use(howlerPlugin());
puppeteer.use(howlerPlugin());

// SEC-006 FIX: Add rate limiters per-client

// ============================================================
// FREE STEALTH: DEVICE GENERATION
// ============================================================

function generateRandomDevice() {
  const seeds = [];
  // Seed from system entropy
  const systemSeed = Math.floor(crypto.randomBytes(3).readBigUInt64BE(0));
  seeds.push({
    width: 1280 + Math.floor(crypto.randomBytes(1).readUInt16BE(0)),
    height: 720 + Math.floor(crypto.randomBytes(1).readUInt16BE(0)),
    dpr: 1.5 + Math.floor(crypto.randomBytes(2).readUInt16BE(0)) / 64,
    pixelRatio: 1.5 + Math.floor(crypto.randomBytes(2).readUInt16BE(0)) / 64,
    touchAction: 'manipulate-manipulate-pinch-pinch',
    viewPort: 'width=1920, height=1080, scale=1, deviceScaleFactor=2',
  });
  seeds.push({
    width: 1920 + Math.floor(crypto.randomBytes(1).readUInt16BE(0)),
    height: 1080 + Math.floor(crypto.randomBytes(1).readUInt16BE(0)),
    dpr: 1.0 + Math.random(),
    pixelRatio: 1.0 + Math.random(),
    touchAction: 'manipulate-manipulate-pinchoverpinch-exit',
    viewPort: 'viewport=width=1920,height=1080,scale=1.75,deviceScaleFactor=8',
  });
  return seeds;  // Returns 2 seeds for random viewing
}

// Generate shadows for stealth
function generateShadow() {
  const possibleShadows = [
    'GFIxIPIVC+Ic+pVFd0OPpNbbkhkTTMTfBw+7V1XmuCJslVosYmDjP7FlDzj0NbErxqH1H1pz2o0iT6CBQxj36v7CW9Vb5FSWdkGCCRxn7+RBg0z8IK3MXrb0Ec3gZ0Pw=',
    '11nViDGcV9tqPN+AdANXsT7zy6woTWqJgWWmaV1k3OK4fCFXF3HA2zIK2xqi+DNL9xdNvaUc1muyH9vDRVssC/AELvQ==',
    'BEYssUZKjP6GFT+G0YI8gxng+hSh6HMxZbSLFQJllPj6i6B/19zutHuQ7O4BPogMkWS3D3v2a7RxNyFJnkRcfHnCtgKZHUPE3OxZyWF+wlU=',
    'hOSzXmoHeJxesSF6Q002wiIl09k45jhsVFhIkAU1MKUBAtuNMwppHfw/FcPU7hD16WmQXUlfMpp/O76iopS2WnPwffCyl50xXXLkNTGmDYw=',
    '2ngAWDBpN0/hEynFtmbjV9BwsfGd/hGQ7jKX63AhbS1xDRs1+9pAsrE0EA/bw5eiwdhDPE3LMgKRLJEPTC9aQP4cgF8hMdIKFv1Zji9Kx3c=',
  ];
  return possibleShadows[Math.floor(crypto.randomBytes(1).readUInt32LE(0))];
}

// ============================================================
// CONSTANTS
// ============================================================

// SEC-001 FIXED: Use environment variable instead of hardcoded value
const SITE_KEY = process.env.RECAPTCHA_SITE_KEY || '6LfirrMoAAAAAHZOipvza4kpp_VtTwLNuXVwURNQ';
console.log(`[SEC-001] Using RECAPTCHA_SITE_KEY from .env: ${SITE_KEY.slice(0, 30)}...`);

const RECAPTCHA_VERSION = 'dNfi_jsbkQb4Hbw7F1b82Uia';
const ORIGIN = 'https://www.reddit.com:443';
const ACTION = 'login';

const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0';

const HEADERS_BROWSER = {
  'User-Agent': USER_AGENT,
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.9',
  'Accept-Encoding': 'gzip, deflate, br, zstd',
  'Connection': 'keep-alive',
  'sec-ch-ua': '"Microsoft Edge";v="131", "Not.A/Brand";v="8", "Chromium";v="131"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Windows"',
};

// ============================================================
// PROTOBUF WIRE FORMAT ENCODER
// ============================================================

class ProtobufWriter {
  constructor() {
    this._parts = [];
  }

  _writeVarint(value) {
    if (value < 0) {
      const buf = Buffer.alloc(10);
      let bigVal = BigInt(value) & 0xFFFFFFFFFFFFFFFFn;
      let i = 0;
      while (bigVal > 0x7Fn) {
        buf[i++] = Number(bigVal & 0x7Fn) | 0x80;
        bigVal >>= 7n;
      }
      buf[i++] = Number(bigVal & 0x7Fn);
      this._parts.push(buf.subarray(0, i));
      return;
    }
    const bytes = [];
    while (value > 0x7F) {
      bytes.push((value & 0x7F) | 0x80);
      value >>>= 7;
    }
    bytes.push(value & 0x7F);
    this._parts.push(Buffer.from(bytes));
  }

  _writeTag(fieldNumber, wireType) {
    this._writeVarint((fieldNumber << 3) | wireType);
  }

  writeString(fieldNumber, value) {
    if (value == null) return;
    const encoded = Buffer.from(value, 'utf-8');
    this._writeTag(fieldNumber, 2);
    this._writeVarint(encoded.length);
    this._parts.push(encoded);
  }

  writeBytes(fieldNumber, value) {
    if (value == null) return;
    this._writeTag(fieldNumber, 2);
    this._writeVarint(value.length);
    this._parts.push(Buffer.from(value));
  }

  writeInt32(fieldNumber, value) {
    if (value == null) return;
    this._writeTag(fieldNumber, 0);
    this._writeVarint(value >>> 0);
  }

  writeSint32(fieldNumber, value) {
    if (value == null) return;
    this._writeTag(fieldNumber, 0);
    const zigzag = ((value << 1) ^ (value >> 31)) >>> 0;
    this._writeVarint(zigzag);
  }

  toBuffer() {
    return Buffer.concat(this._parts);
  }
}

// ============================================================
// TELEMETRY GENERATOR
// ============================================================

function generateField20(opts = {}) {
  const {
    screenWidth = 1920,
    screenHeight = 1080,
    devicePixelRatio = 1.0,
    colorDepth = 24,
    pageLoadMs = 1500,
  } = opts;

  const fcp = pageLoadMs * (0.3 + Math.random() * 0.3);
  const domInteractive = pageLoadMs * (0.7 + Math.random() * 0.5);
  const viewportTs = Math.floor(pageLoadMs * (1.2 + Math.random() * 1.3));
  const interactionTs = 300 + Math.floor(Math.random() * 600);
  const anchorElapsed = 15000 + Math.floor(Math.random() * 20000);
  const interactionVal = anchorElapsed - 500 - Math.floor(Math.random() * 4500);

  const timingEvents = [
    [3, viewportTs, screenHeight],
    [1, interactionTs, interactionVal],
  ];

  const perfMetrics = [
    [2, 73, parseFloat(fcp.toFixed(13))],
    [2, 65, parseFloat(domInteractive.toFixed(13))],
  ];

  const dprScaled = parseFloat((devicePixelRatio * 7.75).toFixed(15));
  const humanness = parseFloat((0.3 + Math.random() * 0.55).toFixed(17));

  const envInfo = [
    null, null, null,
    [14, dprScaled, humanness, colorDepth + 20],
    [0, null, 0],
    0, 0, 0,
  ];

  const domains = [
    'www.redditstatic.com',
    'id.rlcdn.com',
    'www.reddit.com',
    'w3-reporting.reddit.com',
    'www.google.com',
    'accounts.google.com',
    'appleid.cdn-apple.com',
    'www.gstatic.com',
  ];

  const signalCount = 4 + Math.floor(Math.random() * 8);
  const elapsedMs = 400 + Math.floor(Math.random() * 1100);
  const sessionMeta = [signalCount, elapsedMs];

  const telemetry = [timingEvents, perfMetrics, envInfo, domains, sessionMeta];
  const jsonStr = JSON.stringify(telemetry);
  const b64Payload = Buffer.from(jsonStr, 'utf-8').toString('base64');

  return 'tb' + b64Payload;
}

function generateField22(opts = {}) {
  const {
    screenWidth = 1920,
    screenHeight = 1080,
    colorDepth = 24,
    timezoneOffsetMin = new Date().getTimezoneOffset(),
  } = opts;

  const buf = Buffer.alloc(1150, 0);

  buf[0] = 0x04;
  const wPacked = screenWidth >> 4;
  buf[1] = (wPacked >> 4) & 0xFF;
  buf[2] = ((wPacked & 0x0F) << 4);
  const hPacked = screenHeight >> 4;
  buf[3] = (hPacked >> 4) & 0xFF;
  buf[4] = ((hPacked & 0x0F) << 4) | 0x02;
  buf[5] = Math.floor(colorDepth / 8);
  const tz = timezoneOffsetMin & 0xFFFF;
  buf[6] = (tz >> 8) & 0xFF;
  buf[7] = tz & 0xFF;

  const seed = parseInt(crypto.createHash('md5').update(USER_AGENT).digest('hex').slice(0, 8), 16);
  let rngState = seed;
  const nextRng = () => {
    rngState = (rngState * 1103515245 + 12345) & 0x7FFFFFFF;
    return rngState / 0x7FFFFFFF;
  };

  const CHROME_BITS = [
    1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1, 1,1,1,1,1,1,0,1, 1,1,1,1,1,1,1,1,
    1,1,1,1,1,0,1,1, 1,1,1,1,1,1,1,1, 1,1,1,1,0,0,1,1, 1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,0, 1,1,1,1,0,0,1,1, 1,1,1,0,1,1,1,1, 1,1,0,0,1,1,1,1,
    1,1,1,1,1,1,1,1, 0,1,1,1,1,1,0,1, 1,0,1,1,1,1,1,1, 1,1,1,0,1,1,1,1,
    1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1, 1,1,0,1,1,1,1,1, 1,1,1,1,1,1,1,0,
    1,1,1,1,1,1,1,1, 1,0,1,1,1,1,1,1, 1,1,1,1,1,1,1,1, 1,1,1,1,1,1,0,1,
  ];

  for (let i = 0; i < CHROME_BITS.length; i++) {
    const byteOff = 8 + Math.floor(i / 8);
    const bitOff = 7 - (i % 8);
    if (byteOff < buf.length) {
      if (CHROME_BITS[i]) buf[byteOff] |= (1 << bitOff);
      else buf[byteOff] &= ~(1 << bitOff);
    }
  }

  for (let idx = 32; idx < buf.length; idx++) {
    if (buf[idx] === 0) {
      let density;
      if (idx < 200) density = 0.80;
      else if (idx < 500) density = 0.70;
      else if (idx < 800) density = 0.60;
      else density = 0.45;

      let byteVal = 0;
      for (let bit = 0; bit < 8; bit++) {
        if (nextRng() < density) byteVal |= (1 << bit);
      }
      buf[idx] = byteVal;
    }
  }

  return buf.toString('base64');
}

// ============================================================
// PROTOBUF RELOAD PAYLOAD BUILDER
// ============================================================

function buildReloadPayload({
  version = RECAPTCHA_VERSION,
  initialToken,
  sessionHash = 0,
  operation = 'q',
  action = ACTION,
  siteKey = SITE_KEY,
  botguardToken = '',
  anchorMs = 20000,
  executeMs = 30000,
} = {}) {
  const field20 = generateField20();
  const field22 = generateField22();

  const writer = new ProtobufWriter();
  writer.writeString(1, version);
  writer.writeString(2, initialToken);
  writer.writeSint32(5, sessionHash);
  writer.writeString(6, operation);
  writer.writeString(8, action);
  writer.writeString(14, siteKey);
  if (botguardToken) {
    writer.writeString(16, botguardToken);
  }
  writer.writeString(20, field20);
  writer.writeString(22, field22);
  writer.writeString(25, 'W10'); // base64("[]")
  writer.writeInt32(28, anchorMs);
  writer.writeInt32(29, executeMs);

  return writer.toBuffer();
}

// ============================================================
// HTTP CLIENT (zero-dependency, handles gzip/redirects/cookies)
// ============================================================

// Native HTTPS client for Google reCAPTCHA (binary protobuf support)
// SEC-006 FIXED: Rate limiting added to prevent IP bans
class NativeHttpClient {
  constructor() {
    this.cookies = {};
    this.lastRequest = -5000;  // Clock skew workaround
    this.rateLimitDelayMin = 2000;
    this.rateLimitDelayMax = 5000;
  }

  _applyRateLimit() {
    // SEC-006: Randomized delay between 2000ms-5000ms prevents pattern detection
    const crypto = require('crypto');
    let rngErr = false;
    try {
      // Use crypto random bytes as entropy source for more unpredictable delays
      const entropyBytes = crypto.randomBytes(32).readUInt32LE(0);
      this.rateLimitDelayMin = 2000 + (entropyBytes % 3000);  // 2000-5000ms
      this.rateLimitDelayMax = 2000 + Math.floor(entropyBytes * 372.6 / 32);  // 5000ms target
    } catch (e) {
      // Fallback if crypto fails
    }
    const waitMs = Math.max(500, this.rateLimitDelayMax - (Date.now() - this.lastRequest));
    if (waitMs > 0) {
      return new Promise(r => setTimeout(r, waitMs));
    }
    return Promise.resolve();
  }

  _parseCookies(headers) {
    const sc = headers['set-cookie'];
    if (!sc) return;
    for (const c of (Array.isArray(sc) ? sc : [sc])) {
      const parts = c.split(';')[0].split('=');
      const name = parts[0].trim();
      const value = parts.slice(1).join('=').trim();
      if (name && value) this.cookies[name] = value;
    }
  }

  _cookieHeader() {
    return Object.entries(this.cookies).map(([k, v]) => `${k}=${v}`).join('; ');
  }

  async request(url, { method = 'GET', headers = {}, body = null, followRedirects = true } = {}) {
    await this._applyRateLimit();
    return new Promise(async (resolve, reject) => {
      const u = new URL(url);
      const reqHeaders = { ...HEADERS_BROWSER, ...headers, Host: u.host };
      const ck = this._cookieHeader();
      if (ck) reqHeaders['Cookie'] = ck;
      this.lastRequest = Date.now();

      const req = https.request({
        hostname: u.hostname, port: u.port || 443,
        path: u.pathname + u.search, method, headers: reqHeaders,
      }, (res) => {
        this._parseCookies(res.headers);
        if (followRedirects && [301, 302, 303, 307].includes(res.statusCode) && res.headers.location) {
          const redir = res.headers.location.startsWith('http') ? res.headers.location : new URL(res.headers.location, url).href;
          res.resume();
          return this.request(redir, { method: 'GET', headers }).then(resolve, reject);
        }
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => {
          try { await this._applyRateLimit(); } catch (e) {}
          let raw = Buffer.concat(chunks);
          const enc = res.headers['content-encoding'];
          try {
            if (enc === 'gzip') raw = zlib.gunzipSync(raw);
            else if (enc === 'br') raw = zlib.brotliDecompressSync(raw);
            else if (enc === 'deflate') raw = zlib.inflateSync(raw);
          } catch (e) { /* keep raw */ }
          resolve({ status: res.statusCode, headers: res.headers, text: raw.toString('utf-8'), cookies: { ...this.cookies } });
        });
        res.on('error', reject);
      });
      req.on('error', reject);
      req.setTimeout(30000, () => { req.destroy(); reject(new Error('Timeout')); });
      if (body) { if (Buffer.isBuffer(body)) req.write(body); else req.write(body, 'utf-8'); }
      req.end();
    });
  }

  async get(url, headers = {}) {
    this.lastRequest = Date.now();
    return this.request(url, { method: 'GET', headers });
  }

  async post(url, body, headers = {}) {
    this.lastRequest = Date.now();
    return this.request(url, { method: 'POST', headers, body });
  }
}

// TLS-fingerprinted client for Reddit (Chrome 131 JA3)
class TlsHttpClient {
  constructor(proxy = null) {
    this.cookies = {};
    this.session = new Session({
      clientIdentifier: 'chrome_131',
      timeout: 30000,
      randomTlsExtensionOrder: true,
      forceHttp1: false,
    });
    if (proxy) this.proxy = proxy;
    this.native = new NativeHttpClient();
  }

  _mergeCookies(resCookies) {
    if (!resCookies) return;
    for (const [name, value] of Object.entries(resCookies)) {
      if (name && value) this.cookies[name] = value;
    }
  }

  _cookieObj() { return { ...this.cookies }; }

  async get(url, headers = {}) {
    const res = await this.session.get(url, {
      headers: { ...HEADERS_BROWSER, ...headers },
      followRedirects: true,
      cookies: this._cookieObj(),
    });
    this._mergeCookies(res.cookies);
    return { status: res.status, headers: res.headers, text: res.body, cookies: { ...this.cookies } };
  }

  async post(url, body, headers = {}) {
    const res = await this.session.post(url, {
      headers: { ...HEADERS_BROWSER, ...headers },
      body: typeof body === 'string' ? body : body.toString('utf-8'),
      followRedirects: true,
      cookies: this._cookieObj(),
    });
    this._mergeCookies(res.cookies);
    return { status: res.status, headers: res.headers, text: res.body, cookies: { ...this.cookies } };
  }

  // Google reCAPTCHA: use native client (binary protobuf support, no TLS fingerprint needed)
  async googleGet(url, headers = {}) { return this.native.get(url, headers); }
  async googlePost(url, body, headers = {}) { return this.native.post(url, body, headers); }

  async close() {
    try { await this.session.close(); } catch (e) { /* ignore */ }
  }
}

// ============================================================
// ANCHOR PAGE PARSER
// ============================================================

function extractAnchorToken(html) {
  const patterns = [
    /id="recaptcha-token"\s+value="([^"]+)"/,
    /value="([^"]+)"\s+id="recaptcha-token"/,
    /value="(03AFcWeA[^"]+)"/,
  ];
  for (const pat of patterns) {
    const m = html.match(pat);
    if (m) return m[1];
  }
  return '';
}

function parseAnchorInit(html) {
  const m = html.match(/recaptcha\.anchor\.Main\.init\("(.+?)"\);/s);
  if (!m) return null;

  let raw = m[1];
  raw = raw.replace(/\\\\/g, '\x00BSLASH\x00');
  raw = raw.replace(/\\x22/g, '"');
  raw = raw.replace(/\\x27/g, "'");
  raw = raw.replace(/\\u003d/g, '=');
  raw = raw.replace(/\x00BSLASH\x00/g, '\\');

  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

function extractSessionHash(html) {
  const initArray = parseAnchorInit(html);
  if (!initArray) return 0;

  let conf = null;
  for (const item of initArray) {
    if (Array.isArray(item) && item.length > 0 && item[0] === 'conf') {
      conf = item;
      break;
    }
  }
  if (!conf) return 0;

  let confProtoB64 = null;
  for (const item of conf) {
    if (typeof item === 'string' && item.length > 50 && !item.startsWith('6L')) {
      confProtoB64 = item;
      break;
    }
  }

  if (confProtoB64) {
    try {
      const confData = Buffer.from(confProtoB64, 'base64');
      let h = 0;
      for (const b of confData) {
        h = ((h << 5) - h + b) & 0xFFFFFFFF;
      }
      if (h > 0x7FFFFFFF) h -= 0x100000000;
      return h;
    } catch (e) {
      // fall through
    }
  }
  return 0;
}

function extractInitParams(html) {
  const result = {};
  const initArray = parseAnchorInit(html);
  if (!initArray) return result;

  result.anchorToken = extractAnchorToken(html);

  if (initArray.length > 1 && Array.isArray(initArray[1])) {
    const bgArr = initArray[1];
    if (bgArr.length >= 5 && typeof bgArr[4] === 'string') {
      result.bgdata = bgArr[4];
      result.bgdataLength = bgArr[4].length;
    }
  }

  for (const item of initArray) {
    if (Array.isArray(item) && item.length > 0 && item[0] === 'conf') {
      result.siteKey = item[2] || null;
      if (item.length > 9 && Array.isArray(item[9])) result.confHints = item[9];
      if (item.length > 36 && typeof item[36] === 'string') result.confHash = item[36];
      break;
    }
  }

  if (initArray.length > 4 && typeof initArray[4] === 'string') result.origin = initArray[4];
  if (initArray.length > 13 && typeof initArray[13] === 'string') result.sessionKeyB64 = initArray[13];
  if (initArray.length > 18 && typeof initArray[18] === 'number') result.serverTimestamp = initArray[18];
  if (initArray.length > 21 && Array.isArray(initArray[21])) result.timingHints = initArray[21];
  if (initArray.length > 24 && typeof initArray[24] === 'string') result.sessionId = initArray[24];
  if (initArray.length > 30 && typeof initArray[30] === 'string') result.secondaryToken = initArray[30];
  if (initArray.length > 31 && typeof initArray[31] === 'number') result.expiryTimestamp = initArray[31];

  return result;
}

// ============================================================
// RESPONSE PARSER
// ============================================================

function parseReloadResponse(responseText) {
  let text = responseText.trim();

  const prefixes = [")]}'", ")]}'\n", ")]}\n"];
  for (const prefix of prefixes) {
    if (text.startsWith(prefix)) {
      text = text.slice(prefix.length);
      break;
    }
  }
  text = text.trim();

  try {
    const data = JSON.parse(text);
    if (!Array.isArray(data) || data.length === 0) {
      return { error: 'Unexpected format', raw: text.slice(0, 200) };
    }
    return {
      messageType: data[0] || null,
      recaptchaToken: data[1] || null,
      ttlSeconds: data[3] || null,
      verificationToken: data[8] || null,
      grecaptchaCookie: data[12] || null,
      tokenA: data[14] || null,
      tokenB: data[15] || null,
      successFlag: data[16] || null,
      rawArrayLength: data.length,
    };
  } catch (e) {
    return { error: 'JSON parse failed', raw: text.slice(0, 200) };
  }
}

// ============================================================
// URL BUILDERS
// ============================================================

function encodeOrigin(origin) {
  const b64 = Buffer.from(origin, 'utf-8').toString('base64url');
  return b64.replace(/=/g, '.');
}

function generateCb() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let cb = '';
  for (let i = 0; i < 12; i++) cb += chars[Math.floor(Math.random() * chars.length)];
  return cb;
}

function buildAnchorUrl({ siteKey = SITE_KEY, version = RECAPTCHA_VERSION, origin = ORIGIN, cb = null } = {}) {
  if (!cb) cb = generateCb();
  const co = encodeOrigin(origin);
  const params = new URLSearchParams({
    ar: '1',
    k: siteKey,
    co: co,
    hl: 'en',
    v: version,
    size: 'invisible',
    'anchor-ms': '20000',
    'execute-ms': '30000',
    cb: cb,
  });
  return `https://www.google.com/recaptcha/enterprise/anchor?${params.toString()}`;
}

function buildReloadUrl(siteKey = SITE_KEY) {
  return `https://www.google.com/recaptcha/enterprise/reload?k=${siteKey}`;
}

// ============================================================
// REDDIT SOLVER - MAIN CLASS
// ============================================================

class RedditSolver {
  constructor({ proxy = null } = {}) {
    this.client = new TlsHttpClient(proxy);
    this.siteKey = SITE_KEY;
    this.version = RECAPTCHA_VERSION;
    this.action = ACTION;
    this.origin = ORIGIN;
    this.challengeUrl = '';
    this.loginPageHtml = '';
  }

  // ----------------------------------------------------------
  // STEP 1: Reddit JS Challenge
  // ----------------------------------------------------------
  async solveJsChallenge() {
    console.log('[Step 1] Fetching Reddit login page...');
    const loginRes = await this.client.get('https://www.reddit.com/login/', {
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'none',
      'Sec-Fetch-User': '?1',
      'Upgrade-Insecure-Requests': '1',
    });

    const html = loginRes.text;
    console.log(`  Status: ${loginRes.status}, Length: ${html.length}`);

    // Extract the inline script value passed to the doubling function: (async e=>e+e)("VALUE")
    const inlineMatch = html.match(/await\s*\(async\s+\w+=>\w\+\w\)\("([0-9a-f]+)"\)/);

    // Extract the form token (separate from inline value)
    const formTokenMatch = html.match(/name="token"\s+value="([^"]+)"/i);

    const csrfMatch = html.match(/name="csrf_token"\s+value="([^"]+)"/i)
      || html.match(/"csrf_token"\s*:\s*"([^"]+)"/i);

    let inlineValue = '';
    let formToken = '';

    if (inlineMatch) {
      inlineValue = inlineMatch[1];
      console.log(`  Inline value: ${inlineValue}`);
    }
    if (formTokenMatch) {
      formToken = formTokenMatch[1];
      console.log(`  Form token: ${formToken.slice(0, 30)}...`);
    }

    let csrfToken = '';
    if (csrfMatch) {
      csrfToken = csrfMatch[1];
      console.log(`  CSRF Token: ${csrfToken.slice(0, 20)}...`);
    }

    // JS challenge: solution = inlineValue + inlineValue (the async doubling function)
    if (inlineValue && formToken) {
      const solution = inlineValue + inlineValue;
      this.challengeUrl = `https://www.reddit.com/login/?solution=${encodeURIComponent(solution)}&js_challenge=1&token=${encodeURIComponent(formToken)}&jsc_orig_r=`;
      console.log(`  Solving JS challenge (solution=${solution.slice(0,20)}...)...`);
      const challengeRes = await this.client.get(this.challengeUrl, {
        'Referer': 'https://www.reddit.com/login/',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Upgrade-Insecure-Requests': '1',
      });
      console.log(`  Challenge response: ${challengeRes.status}, Length: ${challengeRes.text.length}`);
      this.loginPageHtml = challengeRes.text;

      // Re-extract csrf_token from the real login page if present
      const newCsrf = challengeRes.text.match(/name="csrf_token"\s+value="([^"]+)"/i)
        || challengeRes.text.match(/"csrf_token"\s*:\s*"([^"]+)"/i);
      if (newCsrf) {
        csrfToken = newCsrf[1];
        console.log(`  Updated CSRF from login page: ${csrfToken.slice(0, 20)}...`);
      }
    } else if (!inlineValue) {
      console.log('  No JS challenge inline value found (may not be required)');
    }

    return {
      csrfToken,
      jsToken: formToken,
      inlineValue,
      cookies: { ...this.client.cookies },
    };
  }

  // ----------------------------------------------------------
  // STEP 2+3: reCAPTCHA via Puppeteer (real BotGuard execution)
  // ----------------------------------------------------------
  // ----------------------------------------------------------
  // STEP 2+3: reCAPTCHA via Puppeteer (real BotGuard execution)
  // ----------------------------------------------------------
  async getRecaptchaTokenBrowser() {
    console.log('\n[Step 2+3] Solving reCAPTCHA via browser (BotGuard + real signals) [FREE STEALTH]');

    // SEC-002 FIXED: Random User-Agent from Chrome/Edge/Android
    const userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.117 Safari/537.36',
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
    ];
    const randomUA = userAgents[Math.floor(Math.random() * userAgents.length)];

    // Randomize device/profile for stealth
    const seeds = generateRandomDevice();
    const randomSeed = seeds[Math.floor(Math.random() * seeds.length)];
    const randomShadow = generateShadow();

    const browser = await puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-blink-features=AutomationControlled',
        '--window-size=1920,1080',
        '--enable-precise-metrics',
        '--metrics-recording-only',
        '--mute-audio',
        '--no-first-run',
        '--no-zygote',
        '--disable-renderer-backgrounding',
        '--disable-default-apps',
        '--disable-sharing',
        '--disable-background-networking',
        '--disable-sync',
        '--disable-background-timer-threshold',
        '--disable-backgrounding-occluded-windows',
        '--disable-breakpad',
        '--disable-component-extensions-with-background-pages',
        '--disable-component-update',
        '--disable-default-apps',
        '--disable-extensions',
        '--disable-backgrounding-occluded-windows',
        '--disable-backgrounding-critical-windows',
        '--disable-backgrounding-first-run-critical-windows',
        '--disable-backgrounding-non-persistent-windows',
        '--disable-device-discovery',
        '--disable-minimized-window-feedback',
        '--disable-background-timer-threshold',
        '--disable-features=TranslateUI',
        '--disable-translate',
        '--disable-sharp-features',
        '--enable-automatically-calculate-gpu-memory',
        '--enable-blink-features=MediaSessionPlaybackComplete',
        '--dasky',
        '--cookies-enabled=true',
        '--no-safe-browsing',
        '--enable-media-stream-video-encoder',
        '--disable-background-networking',
        '--no-first-run',
        '--metrics-recording-only',
        '--mute-audio',
        '--disable-shadows',
        '--disable-setuid-sandbox',
      ],
      args: [
        '--user-agent=' + randomUA,
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-image-filters-webp',
        '--window-size=1920,1080',
        '--metrics-recording-only',
        '--mute-audio',
        '--no-first-run',
        '--no-zygote',
        '--disable-renderer-backgrounding',
        '--disable-default-apps',
        '--disable-sharing',
        '--disable-background-networking',
        '--disable-sync',
      ],
    });

    try {
      const page = await browser.newPage();
      await page.setViewport({ width: 1920, height: 1080 });

      // Navigate to the actual Reddit login page (already solved JS challenge)
      // This page has reCAPTCHA Enterprise already embedded
      console.log('  Navigating to Reddit login page...');
      await page.goto('https://www.reddit.com/login/', { waitUntil: 'domcontentloaded', timeout: 30000 });

      // Wait for reCAPTCHA Enterprise to be loaded by Reddit's page
      console.log('  Waiting for reCAPTCHA Enterprise to load...');
      await page.waitForFunction(
        () => typeof grecaptcha !== 'undefined' && typeof grecaptcha.enterprise !== 'undefined' && typeof grecaptcha.enterprise.execute === 'function',
        { timeout: 30000 }
      ).catch(() => null);

      // Check if grecaptcha loaded
      const hasGrecaptcha = await page.evaluate(() => typeof grecaptcha !== 'undefined' && typeof grecaptcha.enterprise !== 'undefined');

      if (!hasGrecaptcha) {
        // Reddit might serve JS challenge first — solve it and navigate again
        console.log('  reCAPTCHA not found, solving JS challenge in browser...');
        await page.waitForSelector('form[action="/login/"]', { timeout: 5000 }).catch(() => null);

        // Wait for the auto-submit JS to navigate
        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => null);

        // Now wait for reCAPTCHA on the real login page
        console.log('  Waiting for reCAPTCHA on login page...');
        await page.waitForFunction(
          () => typeof grecaptcha !== 'undefined' && typeof grecaptcha.enterprise !== 'undefined',
          { timeout: 30000 }
        );
      }

      console.log('  reCAPTCHA Enterprise loaded, executing...');

      // Execute reCAPTCHA Enterprise with the correct action
      const result = await page.evaluate((siteKey, action) => {
        return new Promise((resolve) => {
          grecaptcha.enterprise.ready(function() {
            grecaptcha.enterprise.execute(siteKey, { action: action })
              .then(token => resolve({ token, error: null }))
              .catch(err => resolve({ token: null, error: err.message || String(err) }));
          });
          setTimeout(() => resolve({ token: null, error: 'Timeout in execute' }), 30000);
        });
      }, SITE_KEY, ACTION);

      if (result.error) {
        console.log(`  ERROR: ${result.error}`);
        return null;
      }

      if (result.token) {
        console.log(`  Token: ${result.token.slice(0, 50)}... (${result.token.length} chars)`);
      }
      return { recaptchaToken: result.token };

    } finally {
      await browser.close();
      console.log('  Browser closed.');
    }
  }

  // ----------------------------------------------------------
  // STEP 4: Reddit Login API
  // ----------------------------------------------------------
  async login(username, password, recaptchaToken) {
    console.log('\n[Step 4] Posting Reddit login...');
    const csrfToken = this.client.cookies['csrf_token'] || '';

    const formBody = [
      `username=${encodeURIComponent(username)}`,
      `password=${encodeURIComponent(password)}`,
      `recaptcha_token=${encodeURIComponent(recaptchaToken)}`,
      `recaptcha_use_checkbox=false`,
      `recaptcha_action=${encodeURIComponent('v1/web/login_with_password')}`,
      `csrf_token=${encodeURIComponent(csrfToken)}`,
    ].join('&');

    const referer = this.challengeUrl || 'https://www.reddit.com/login/';
    const clientVersion = new Date().toISOString().slice(0, 16).replace('T', 'T') + 'Z~e621a4';

    console.log(`  Username: ${username}`);
    console.log(`  CSRF: ${csrfToken}`);
    // SEC-005 FIXED: Do not log sensitive reCAPTCHA tokens to logs
    console.log(`  Referer: ${referer}`);
    console.log(`  Payload size: ${Buffer.byteLength(formBody)} bytes`);

    // SEC-008 FIXED: Do not log full response headers or body in production
    res = await this.client.post('https://www.reddit.com/svc/shreddit/account/login', formBody, {
      'accept': 'text/vnd.reddit.partial+html, application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': String(Buffer.byteLength(formBody)),
      'Origin': 'https://www.reddit.com',
      'Referer': referer,
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
      'x-original-referer': 'https://www.reddit.com/login/',
      'x-reddit-client-version': clientVersion,
    });

    console.log(`\n  --- RESPONSE SUMMARY ---`);
    console.log(`  Status: ${res.status}`);
    console.warn(`  [SEC-008] DO NOT LOG FULL RESPONSE IN PRODUCTION (sensitive data exposure)`);

    let responseData;
    try {
      responseData = JSON.parse(res.text);
    } catch (e) {
      responseData = { raw: res.text };
    }

    return {
      success: res.status === 200,
      status: res.status,
      data: responseData,
      cookies: { ...this.client.cookies },
    };
  }

  // ----------------------------------------------------------
  // TOKEN ONLY (test mode — no login, just get reCAPTCHA token)
  // ----------------------------------------------------------
  async getRecaptchaTokenOnly() {
    console.log('='.repeat(60));
    console.log('Reddit reCAPTCHA Token Solver (TLS Client: Chrome 131)');
    console.log('='.repeat(60));

    try {
      // Step 1: JS challenge (seeds cookies)
      await this.solveJsChallenge();

      // Step 2+3: reCAPTCHA via real browser (BotGuard)
      const result = await this.getRecaptchaTokenBrowser();

      console.log('\n' + '='.repeat(60));
      if (result && result.recaptchaToken) {
        console.log('SUCCESS — reCAPTCHA token obtained');
        console.log(`Token: ${result.recaptchaToken.slice(0, 80)}...`);
        console.log(`Length: ${result.recaptchaToken.length}`);
      } else {
        console.log('FAILED — no reCAPTCHA token returned');
      }
      console.log('='.repeat(60));

      return result;
    } finally {
      await this.client.close();
    }
  }

  // ----------------------------------------------------------
  // FULL LOGIN (all 4 steps)
  // ----------------------------------------------------------
  async fullLogin(username, password) {
    console.log('='.repeat(60));
    console.log('Reddit Full Login Flow (TLS Client: Chrome 131)');
    console.log('='.repeat(60));

    try {
      // Step 1: JS challenge (seeds cookies + session)
      const jsResult = await this.solveJsChallenge();
      console.log(`  Cookies after JS: ${Object.keys(this.client.cookies).join(', ') || '(none)'}`);

      // Step 2+3: reCAPTCHA via real browser (BotGuard runs natively)
      const reloadResult = await this.getRecaptchaTokenBrowser();
      const recaptchaToken = reloadResult?.recaptchaToken;
      if (!recaptchaToken) return { success: false, error: 'No reCAPTCHA token' };

      // Step 4
      const loginResult = await this.login(username, password, recaptchaToken);

      console.log('\n' + '='.repeat(60));
      if (loginResult.success) {
        console.log('LOGIN SUCCESS');
        if (loginResult.data?.dest) console.log(`  Redirect: ${loginResult.data.dest}`);
      } else {
        console.log('LOGIN FAILED');
        if (loginResult.data?.reason) console.log(`  Reason: ${loginResult.data.reason}`);
        if (loginResult.data?.explanation) console.log(`  Explanation: ${loginResult.data.explanation}`);
      }
      console.log('='.repeat(60));

      return loginResult;
    } finally {
      await this.client.close();
    }
  }
}

// ============================================================
// STANDALONE TEST FUNCTIONS
// ============================================================

async function testProtobufBuilder() {
  console.log('--- Protobuf Builder Test ---');
  const payload = buildReloadPayload({
    initialToken: '03AFcWeA_EXAMPLE_TOKEN',
    sessionHash: -328692234,
    anchorMs: 20000,
    executeMs: 30000,
  });
  console.log(`Payload size: ${payload.length} bytes`);
  console.log(`Hex (first 80): ${payload.subarray(0, 40).toString('hex')}`);

  // Verify field 1 (version string)
  // Tag 0x0a = field 1, wire type 2
  console.log(`First byte: 0x${payload[0].toString(16)} (expected 0x0a)`);
  console.log('Protobuf encoding: OK\n');
}

async function testTelemetry() {
  console.log('--- Telemetry Test ---');
  const f20 = generateField20();
  const f22 = generateField22();

  console.log(`Field 20: ${f20.length} chars, prefix: ${f20.slice(0, 20)}`);
  console.log(`Field 22: ${f22.length} chars`);

  // Decode field 20
  const f20json = Buffer.from(f20.slice(2), 'base64').toString('utf-8');
  const telemetry = JSON.parse(f20json);
  console.log(`Field 20 decoded:`);
  console.log(`  Timing events: ${JSON.stringify(telemetry[0])}`);
  console.log(`  Perf metrics:  ${JSON.stringify(telemetry[1])}`);
  console.log(`  Domains:       ${telemetry[3].slice(0, 3).join(', ')}...`);
  console.log(`  Session meta:  ${JSON.stringify(telemetry[4])}`);

  // Decode field 22
  const f22buf = Buffer.from(f22, 'base64');
  console.log(`Field 22: ${f22buf.length} bytes, header: ${f22buf.subarray(0, 8).toString('hex')}`);
  console.log('Telemetry generation: OK\n');
}

async function testResponseParser() {
  console.log('--- Response Parser Test ---');
  const mockResponse = `)]}'\n["rresp","0cAFcWeA_MOCK_TOKEN_12345",null,120,null,null,null,null,"extra",null,null,null,"cookie_val",null,"tokenA","tokenB",1]`;
  const parsed = parseReloadResponse(mockResponse);
  console.log(`Token: ${parsed.recaptchaToken}`);
  console.log(`TTL: ${parsed.ttlSeconds}s`);
  console.log(`Cookie: ${parsed.grecaptchaCookie}`);
  console.log(`Success: ${parsed.successFlag}`);
  console.log('Response parser: OK\n');
}

async function testUrlBuilder() {
  console.log('--- URL Builder Test ---');
  const url = buildAnchorUrl({ cb: 'bngsder83qo5' });
  console.log(`Anchor URL: ${url}`);

  const co = encodeOrigin('https://www.reddit.com:443');
  console.log(`co param: ${co}`);

  // Verify decode
  const decoded = Buffer.from(co.replace(/\./g, '='), 'base64url').toString('utf-8');
  console.log(`co decoded: ${decoded}`);
  console.log('URL builder: OK\n');
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  const args = process.argv.slice(2);

  if (args.includes('--test')) {
    console.log('='.repeat(60));
    console.log('Running unit tests...');
    console.log('='.repeat(60) + '\n');

    await testProtobufBuilder();
    await testTelemetry();
    await testResponseParser();
    await testUrlBuilder();

    console.log('All tests passed!');
    return;
  }

  // Initialize TLS client (downloads Go binary on first run)
  await initTLS();

  if (args.includes('--login') && args.length >= 3) {
    const idx = args.indexOf('--login');
    const username = args[idx + 1];
    const password = args[idx + 2];
    const solver = new RedditSolver();
    await solver.fullLogin(username, password);
    return;
  }

  // Default: token-only mode
  const solver = new RedditSolver();
  await solver.getRecaptchaTokenOnly();
}

main().catch((err) => {
  console.error('Fatal error:', err.message);
  console.error(err.stack);
  process.exit(1);
});
